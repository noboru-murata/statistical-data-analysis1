### 配列の例 
(A <- array(1:13,dim=c(3,4,2))) # 3x4x2次の配列
### データ例 datasets::Titanic (詳細は help(Titanic))
dim(Titanic)  # 大きさを確認
Titanic       # データを表示
plot(Titanic) # タイル図として表示

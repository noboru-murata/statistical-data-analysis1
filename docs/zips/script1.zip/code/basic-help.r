### 関数helpの使い方
help(sin) # 三角関数のヘルプを見る
?log # ? は help() の代替
### 関数help.searchの使い方
help.search("histogram") # ヒストグラム関連の情報を探す
??random # ?? は help.search() の代替

(1 + 3) * (2 + 4) / 6 # 四則演算
1.8 + 5 - 0.04 + 8.2 / 3 # 計算順に注意
pi # π(パイ) は定義されている 
print(pi,digits=22) # 桁数を変更して表示
sqrt(2) # 平方根 
8^(1/3) # 羃乗
exp(10) # 指数関数
exp(1) # 自然対数の底
log(10) # 対数関数 (log, log10, log2)
sin(pi/2) # 三角関数 (sin, cos, tan)
sinpi(2/3) # sinpi(x) = sin(pi*x)
acos(1/2) # 逆三角関数 (asin, acos, atan)

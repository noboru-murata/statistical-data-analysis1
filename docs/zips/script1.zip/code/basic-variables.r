x <- sin(pi/3) # x に代入
print(x) # x の値を確認
y <- cos(pi/3) # y に代入
y # print(y) と同じ，y の値を確認
z <- x - y # 計算結果を代入
(z) # print(z) と同じ，z の値を確認
(w <- x * y) # print(w <- x * y) と同じ，代入結果を表示
w # 代入結果を確認 (上と同じ値が表示される)
